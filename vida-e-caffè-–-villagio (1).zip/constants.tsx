
import { MenuItem, Review, OpeningHours } from './types';

export const MENU_ITEMS: MenuItem[] = [
  // COFFEE
  { id: 'c1', name: 'Espresso Double', description: 'Strong, rich double shot of our 100% Arabica signature blend.', price: 'GHS 15.00', image: 'https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&q=80&w=400', category: 'Coffee' },
  { id: 'c2', name: 'Cappuccino', description: 'Espresso, steamed milk, and dense velvety foam with chocolate dusting.', price: 'GHS 22.00', image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&q=80&w=400', category: 'Coffee' },
  { id: 'c3', name: 'Meia de Leite', description: 'Traditional Portuguese style: half espresso, half steamed milk.', price: 'GHS 20.00', image: 'https://i.ibb.co/zTTGJhWr/meia-de-leite-direta.jpg', category: 'Coffee' },
  { id: 'c4', name: 'Caffè Latte', description: 'Smooth espresso with creamy steamed milk and a thin layer of foam.', price: 'GHS 24.00', image: 'https://i.ibb.co/DDsXYgTk/cafe-latte.jpg', category: 'Coffee' },
  { id: 'c5', name: 'Vanilla Iced Latte', description: 'Double espresso over ice with milk and Madagascar vanilla syrup.', price: 'GHS 28.00', image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&q=80&w=400', category: 'Coffee' },
  { id: 'c6', name: 'Mocha Frio', description: 'Blended chocolate coffee treat topped with whipped cream.', price: 'GHS 32.00', image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&q=80&w=400', category: 'Coffee' },

  // FOOD (SIGNATURE MEALS)
  { id: 'f1', name: 'Jollof with Gizzard', description: 'Spicy Ghanaian Jollof served with fried plantain and gizzard.', price: 'GHS 48.00', image: 'https://i.ibb.co/yBpvNYDG/mqdefault.jpg', category: 'Food' },
  { id: 'f2', name: 'Grilled Chicken Jollof', description: 'Quarter chicken marinated in local spices, served with Jollof.', price: 'GHS 55.00', image: 'https://i.ibb.co/Z60LZCDb/delicious-jollof-rice-served-grilled-chicken-plantains-west-africa-enjoying-vibrant-plate-accompanie.webp', category: 'Food' },
  { id: 'f3', name: 'Vida Burger', description: 'Beef patty, caramelized onions, cheddar, and our signature sauce.', price: 'GHS 42.00', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=400', category: 'Food' },
  { id: 'f4', name: 'Beef Lasagna', description: 'Traditional layers of pasta, Bolognese, and creamy béchamel.', price: 'GHS 50.00', image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&q=80&w=400', category: 'Food' },
  { id: 'f5', name: 'Tuna Melt Panini', description: 'Toasted ciabatta with seasoned tuna, mozzarella, and onions.', price: 'GHS 38.00', image: 'https://images.unsplash.com/photo-1528736235302-52922df5c122?auto=format&fit=crop&q=80&w=400', category: 'Food' },

  // BREAKFAST
  { id: 'b1', name: 'Avocado Toast', description: 'Smashed avocado on sourdough with poached eggs and chili flakes.', price: 'GHS 35.00', image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=400', category: 'Breakfast' },
  { id: 'b2', name: 'Full English', description: 'Eggs, bacon, sausage, beans, grilled tomato, and toast.', price: 'GHS 60.00', image: 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&q=80&w=400', category: 'Breakfast' },
  { id: 'b3', name: 'Pancake Stack', description: 'Three fluffy pancakes with maple syrup and fresh berries.', price: 'GHS 30.00', image: 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&q=80&w=400', category: 'Breakfast' },
  { id: 'b4', name: 'Greek Yogurt Bowl', description: 'Thick yogurt with granola, local honey, and seasonal fruit.', price: 'GHS 32.00', image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=400', category: 'Breakfast' },

  // PASTRIES
  { id: 'p1', name: 'Butter Croissant', description: 'Flaky, buttery, and golden. Baked fresh every morning.', price: 'GHS 12.00', image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=400', category: 'Pastries' },
  { id: 'p2', name: 'Chocolate Brownie', description: 'Decadent dark chocolate brownie with a gooey center.', price: 'GHS 18.00', image: 'https://i.ibb.co/QF4D6wsg/Brownie-Recipe-with-Cocoa-Powder-1200x821-1.jpg', category: 'Pastries' },
  { id: 'p3', name: 'Blueberry Muffin', description: 'Bursting with fresh blueberries and topped with sugar crumbles.', price: 'GHS 15.00', image: 'https://images.unsplash.com/photo-1558401391-7899b4bd5bbf?auto=format&fit=crop&q=80&w=400', category: 'Pastries' },
  { id: 'p4', name: 'Portuguese Tart', description: 'Our famous Pastel de Nata with creamy custard in a crisp shell.', price: 'GHS 10.00', image: 'https://i.ibb.co/CfBW1fs/images-14.jpg', category: 'Pastries' }
];

export const REVIEWS: Review[] = [
  { id: 'r1', author: 'Daniel Adjei', rating: 5, comment: 'The Villagio branch is my favorite. It’s significantly more peaceful than the others. Great for working remotely.', date: '3 days ago' },
  { id: 'r2', author: 'Akosua Boadi', rating: 4, comment: 'I love their Jollof! The portions are generous and the chicken is always well-seasoned. Coffee is consistently good.', date: '1 week ago' },
  { id: 'r3', author: 'Michael Thompson', rating: 5, comment: 'Best espresso in Accra, hands down. The staff at Villagio are incredibly friendly and efficient.', date: '2 weeks ago' },
  { id: 'r4', author: 'Sarah Mensah', rating: 5, comment: 'Perfect meeting spot. The vibe is sophisticated and the outdoor seating is lovely in the evenings.', date: '1 month ago' },
  { id: 'r5', author: 'Jason Kwakye', rating: 4, comment: 'The brownies are legendary. Always fresh. Great place for a quick breakfast before heading to the office.', date: '2 months ago' },
  { id: 'r6', author: 'Efua Osei', rating: 5, comment: 'I visit every weekend for the Avocado toast. Best quality ingredients and beautiful presentation.', date: '3 months ago' }
];

export const BUSINESS_HOURS: OpeningHours[] = [
  { day: 'Monday – Sunday', hours: '07:00 AM – 08:00 PM' }
];
