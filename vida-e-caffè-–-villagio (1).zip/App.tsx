
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import FullMenu from './components/FullMenu';
import Reviews from './components/Reviews';
import Contact from './components/Contact';
import Footer from './components/Footer';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const PageWrapper: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <div className={`pt-32 pb-20 px-4 reveal ${className}`}>
    {children}
  </div>
);

const Home: React.FC = () => (
  <div className="flex flex-col">
    <Hero />
    
    {/* Decorative Background Text Layer */}
    <div className="relative overflow-hidden">
      <div className="absolute top-40 -left-20 text-[20vw] font-display font-black text-coffee-100/50 select-none pointer-events-none rotate-90 lg:rotate-0">
        TRADIÇÃO
      </div>
      
      <section className="relative z-10 py-32 px-4 bg-white/80 backdrop-blur-sm reveal">
        <About />
      </section>

      <div className="absolute top-[40%] -right-20 text-[20vw] font-display font-black text-coffee-100/50 select-none pointer-events-none">
        MENU
      </div>

      <section className="relative z-10 py-32 px-4 bg-stone-50/50 reveal">
        <Menu />
      </section>
      
      <section className="relative z-10 py-32 px-4 bg-white reveal">
        <Reviews />
      </section>

      <div className="absolute bottom-40 -left-10 text-[20vw] font-display font-black text-coffee-100/50 select-none pointer-events-none">
        LOCALE
      </div>

      <section className="relative z-10 py-32 px-4 bg-stone-50 reveal">
        <Contact />
      </section>
    </div>
  </div>
);

const AppContent: React.FC = () => {
  const location = useLocation();

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { 
      threshold: 0.05,
      rootMargin: "0px 0px -50px 0px"
    });

    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, [location]);

  return (
    <div className="min-h-screen font-sans text-gray-900 bg-stone-50 flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          
          <Route path="/about" element={
            <PageWrapper className="bg-white">
              <About />
            </PageWrapper>
          } />
          
          <Route path="/menu" element={
            <PageWrapper className="bg-stone-50">
              <Menu />
            </PageWrapper>
          } />
          
          <Route path="/catalog" element={
            <PageWrapper className="bg-stone-50">
              <FullMenu />
            </PageWrapper>
          } />
          
          <Route path="/reviews" element={
            <PageWrapper className="bg-white">
              <Reviews />
            </PageWrapper>
          } />
          
          <Route path="/contact" element={
            <PageWrapper className="bg-white">
              <Contact />
            </PageWrapper>
          } />
        </Routes>
      </main>
      
      <Footer />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <AppContent />
    </Router>
  );
};

export default App;
