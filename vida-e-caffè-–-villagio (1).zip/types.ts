
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: string;
  image: string;
  category: 'Coffee' | 'Food' | 'Pastries' | 'Breakfast';
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface OpeningHours {
  day: string;
  hours: string;
}
