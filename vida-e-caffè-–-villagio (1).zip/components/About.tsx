
import React from 'react';
import { ShieldCheck, Leaf, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto space-y-40">
      {/* Our Story Section */}
      <section className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
        <div className="relative">
          <div className="relative z-10 aspect-[4/5] md:aspect-[4/3] rounded-[3rem] overflow-hidden shadow-2xl bg-coffee-100">
            <img 
              src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=1600" 
              alt="Sophisticated Café Atmosphere at Villagio" 
              className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
            />
          </div>
          <div className="absolute -bottom-6 left-6 bg-white p-6 rounded-3xl shadow-xl z-20 max-w-[200px] border border-stone-100">
             <p className="text-accent font-display italic text-xl">Since 2012</p>
             <p className="text-[10px] uppercase tracking-widest text-coffee-400 font-bold mt-1">Serving Villagio since the towers rose.</p>
          </div>
        </div>
        
        <div className="flex flex-col">
          <h2 className="text-accent font-bold tracking-[0.3em] uppercase text-xs mb-8">Our Story</h2>
          <h3 className="text-4xl md:text-6xl font-display font-bold text-coffee-800 mb-10 leading-[1.1] tracking-tight">
            A sanctuary for <br/>
            <span className="text-accent italic font-normal">the coffee refined.</span>
          </h3>
          <div className="space-y-6 text-coffee-600 text-lg leading-relaxed">
            <p>
              Vida e Caffè Villagio isn't just a coffee shop; it's a piece of Accra's modern history. Located in the iconic Villagio Primavera towers, we have served as the heartbeat of this elite community for over a decade.
            </p>
            <p>
              Inspired by the street cafés of Portugal, we brought a high-energy, boutique experience to Ghana. Our Villagio location specifically offers a serene alternative to the city's faster-paced branches, making it the preferred choice for business meetings and quiet morning rituals.
            </p>
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="grid lg:grid-cols-3 gap-12">
        <div className="group p-12 bg-coffee-50 rounded-[3rem] border border-coffee-100 hover:bg-white transition-colors duration-500">
          <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center text-accent mb-8 group-hover:scale-110 transition-transform">
            <ShieldCheck size={32} />
          </div>
          <h4 className="text-2xl font-display font-bold text-coffee-800 mb-6">Quality Guarantee</h4>
          <p className="text-coffee-600 leading-relaxed">
            We use only 100% Arabica beans, roasted in small batches to preserve the delicate oils and complex aromas that define our signature blend.
          </p>
        </div>
        <div className="group p-12 bg-coffee-950 text-white rounded-[3rem] shadow-2xl">
          <div className="w-16 h-16 bg-accent rounded-2xl flex items-center justify-center text-white mb-8 group-hover:scale-110 transition-transform">
            <Leaf size={32} />
          </div>
          <h4 className="text-2xl font-display font-bold text-accent mb-6">Sustainable Sourcing</h4>
          <p className="text-white/70 leading-relaxed">
            Every bean is ethically sourced, supporting farming communities across Africa and South America while ensuring the highest environmental standards.
          </p>
        </div>
        <div className="group p-12 bg-coffee-50 rounded-[3rem] border border-coffee-100 hover:bg-white transition-colors duration-500">
          <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center text-accent mb-8 group-hover:scale-110 transition-transform">
            <Users size={32} />
          </div>
          <h4 className="text-2xl font-display font-bold text-coffee-800 mb-6">The Community</h4>
          <p className="text-coffee-600 leading-relaxed">
            We pride ourselves on being a local hub. We source fresh Ghanaian ingredients for our food menu while maintaining global coffee standards.
          </p>
        </div>
      </section>

      {/* The Vibe Section */}
      <section className="relative rounded-[4rem] overflow-hidden bg-coffee-900 py-32 px-12 text-center">
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center" />
        <div className="relative z-10 max-w-3xl mx-auto">
          <h3 className="text-4xl md:text-5xl font-display font-bold text-white mb-8 italic">"The best stories are told over a double espresso."</h3>
          <p className="text-white/70 text-lg leading-relaxed mb-12">
            Whether you're closing a deal, catching up with an old friend, or simply finding a moment of peace in the middle of a busy week, Vida e Caffè Villagio is designed to be your third home.
          </p>
          <div className="flex flex-wrap justify-center gap-12">
            <div className="text-center">
              <p className="text-accent text-5xl font-display font-bold">4.3</p>
              <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold mt-2">Avg. Rating</p>
            </div>
            <div className="text-center">
              <p className="text-accent text-5xl font-display font-bold">120k+</p>
              <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold mt-2">Happy Guests</p>
            </div>
            <div className="text-center">
              <p className="text-accent text-5xl font-display font-bold">12yr</p>
              <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold mt-2">History</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
