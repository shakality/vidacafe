
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MENU_ITEMS } from '../constants';
import { ArrowLeft, Coffee, Utensils, Zap, Clock, Cookie } from 'lucide-react';

const FullMenu: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const filteredItems = activeCategory === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  const categories = [
    { name: 'All', icon: Zap },
    { name: 'Coffee', icon: Coffee },
    { name: 'Food', icon: Utensils },
    { name: 'Breakfast', icon: Clock },
    { name: 'Pastries', icon: Cookie },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-16">
        <div>
          <Link 
            to="/menu"
            className="flex items-center gap-2 text-accent font-bold uppercase tracking-widest text-xs mb-8 group"
          >
            <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
            Back to Highlights
          </Link>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-coffee-800 tracking-tighter">
            Full <span className="text-accent italic">Catalog</span>
          </h1>
        </div>

        <div className="flex flex-wrap gap-2 bg-coffee-100 p-2 rounded-2xl border border-coffee-200">
          {categories.map((cat) => (
            <button
              key={cat.name}
              onClick={() => setActiveCategory(cat.name)}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all ${
                activeCategory === cat.name 
                ? 'bg-white text-coffee-950 shadow-sm' 
                : 'text-coffee-500 hover:text-coffee-800'
              }`}
            >
              <cat.icon size={16} />
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {filteredItems.map((item) => (
          <div key={item.id} className="group bg-white rounded-[2rem] border border-stone-100 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 reveal">
            <div className="aspect-square overflow-hidden relative">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest text-coffee-800">
                {item.category}
              </div>
            </div>
            <div className="p-6">
              <h4 className="text-xl font-display font-bold text-coffee-950 mb-2">{item.name}</h4>
              <p className="text-sm text-coffee-500 line-clamp-2 mb-4 leading-relaxed">{item.description}</p>
              <div className="flex items-center justify-between pt-4 border-t border-stone-50">
                <span className="text-lg font-display italic text-accent font-bold">{item.price}</span>
                <button className="text-[10px] uppercase tracking-[0.2em] font-black px-4 py-2 bg-coffee-50 rounded-full hover:bg-accent hover:text-white transition-colors">Details</button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredItems.length === 0 && (
        <div className="text-center py-20">
          <p className="text-coffee-400 font-display italic text-2xl">No items found in this category.</p>
        </div>
      )}
    </div>
  );
};

export default FullMenu;
