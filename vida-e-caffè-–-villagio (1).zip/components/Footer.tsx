
import React from 'react';
import { Link } from 'react-router-dom';
import { Coffee, Instagram, Facebook, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-stone-100 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid lg:grid-cols-4 gap-16 mb-16">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-8">
              <div className="p-2 bg-coffee-950 rounded-lg">
                <Coffee className="w-6 h-6 text-accent" />
              </div>
              <span className="text-2xl font-display font-bold text-coffee-950 tracking-tighter">Vida e Caffè</span>
            </div>
            <p className="text-gray-500 max-w-sm mb-8 leading-relaxed">
              Bringing the authentic European-inspired café culture to the heart of Accra. Quality coffee, fresh local meals, and the most serene vibe in Villagio.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-12 h-12 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-center text-coffee-600 hover:bg-accent hover:border-accent hover:text-white transition-all duration-500">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-center text-coffee-600 hover:bg-accent hover:border-accent hover:text-white transition-all duration-500">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-center text-coffee-600 hover:bg-accent hover:border-accent hover:text-white transition-all duration-500">
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-coffee-950 uppercase tracking-widest text-xs mb-8">Explore</h4>
            <ul className="space-y-4">
              <li><Link to="/" className="text-gray-500 hover:text-accent transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-gray-500 hover:text-accent transition-colors">Our Story</Link></li>
              <li><Link to="/menu" className="text-gray-500 hover:text-accent transition-colors">Curated Menu</Link></li>
              <li><Link to="/catalog" className="text-gray-500 hover:text-accent transition-colors">Full Catalog</Link></li>
              <li><Link to="/reviews" className="text-gray-500 hover:text-accent transition-colors">Guest Reviews</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-coffee-950 uppercase tracking-widest text-xs mb-8">Contact</h4>
            <ul className="space-y-4 text-gray-500">
              <li>JRCC+3Q6, Accra, Ghana</li>
              <li className="font-bold text-coffee-800">054 010 2889</li>
              <li>villagio@vidacaffe.gh</li>
              <li><Link to="/contact" className="inline-block mt-4 px-6 py-2 border-2 border-coffee-100 rounded-full hover:border-accent hover:text-accent transition-all">Find Us</Link></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-stone-100 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
          <p>© {new Date().getFullYear()} Vida e Caffè – Villagio Tower. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-accent transition-colors">Privacy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
