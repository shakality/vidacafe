
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { REVIEWS } from '../constants';

const Reviews: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <h2 className="text-coffee-600 font-semibold tracking-widest uppercase text-sm mb-4">Testimonials</h2>
          <h3 className="text-4xl font-display font-bold text-gray-900">What Our Guests Say</h3>
        </div>
        <div className="bg-coffee-50 p-6 rounded-3xl border border-coffee-100 flex items-center gap-6">
          <div className="text-center">
            <span className="block text-4xl font-bold text-coffee-950">4.3</span>
            <div className="flex text-amber-500 justify-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} fill={i < 4 ? "currentColor" : "none"} stroke="currentColor" />
              ))}
            </div>
          </div>
          <div className="h-10 w-px bg-coffee-200" />
          <div>
            <span className="block font-bold text-coffee-950">260+ Reviews</span>
            <span className="text-sm text-gray-500">Verified Google Rating</span>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {REVIEWS.map((review) => (
          <div key={review.id} className="relative p-8 bg-stone-50 rounded-3xl border border-stone-200 shadow-sm flex flex-col h-full">
            <Quote className="absolute top-6 right-8 text-coffee-200" size={40} />
            <div className="flex text-amber-500 mb-4">
              {[...Array(review.rating)].map((_, i) => (
                <Star key={i} size={18} fill="currentColor" stroke="currentColor" />
              ))}
            </div>
            <p className="text-gray-700 italic text-lg leading-relaxed flex-grow mb-6">
              "{review.comment}"
            </p>
            <div>
              <p className="font-bold text-gray-900">{review.author}</p>
              <p className="text-sm text-gray-400">{review.date}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Reviews;
