
import React from 'react';
import { Clock, Coffee } from 'lucide-react';
import { BUSINESS_HOURS } from '../constants';

const OpeningHours: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto bg-coffee-950 text-white rounded-[40px] overflow-hidden shadow-2xl flex flex-col md:flex-row">
      <div className="md:w-1/2 p-12 bg-coffee-900 flex flex-col justify-center">
        <div className="w-16 h-16 bg-coffee-800 rounded-2xl flex items-center justify-center mb-8">
          <Clock className="w-8 h-8 text-coffee-300" />
        </div>
        <h3 className="text-3xl font-display font-bold mb-4">Opening Hours</h3>
        <p className="text-coffee-200 leading-relaxed mb-6">
          We are open every day of the week to ensure you never have to go without your favorite caffeine fix or meal.
        </p>
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-full text-sm font-semibold self-start">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          Open Now
        </div>
      </div>
      
      <div className="md:w-1/2 p-12 flex flex-col justify-center">
        <div className="space-y-6">
          {BUSINESS_HOURS.map((slot, idx) => (
            <div key={idx} className="flex justify-between items-center pb-4 border-b border-coffee-800 last:border-0">
              <span className="text-lg font-medium text-coffee-100">{slot.day}</span>
              <span className="text-xl font-bold text-coffee-400">{slot.hours}</span>
            </div>
          ))}
        </div>
        <div className="mt-12 p-6 bg-coffee-900 rounded-3xl flex items-center gap-4">
          <div className="p-3 bg-coffee-800 rounded-xl">
            <Coffee className="w-6 h-6 text-coffee-400" />
          </div>
          <p className="text-sm text-coffee-200">
            Popular times: 8:00 AM – 10:30 AM. <br/>
            Join us for breakfast!
          </p>
        </div>
      </div>
    </div>
  );
};

export default OpeningHours;
