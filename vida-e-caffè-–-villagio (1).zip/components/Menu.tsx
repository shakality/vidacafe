
import React from 'react';
import { Link } from 'react-router-dom';
import { MENU_ITEMS } from '../constants';
import { Coffee, Utensils, Sandwich, Cookie } from 'lucide-react';

const Menu: React.FC = () => {
  const getHighlights = (category: string, limit: number) => 
    MENU_ITEMS.filter(item => item.category === category).slice(0, limit);

  return (
    <div className="max-w-7xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
        <div className="max-w-2xl">
          <h2 className="text-accent font-bold tracking-[0.3em] uppercase text-xs mb-4">Curated Selection</h2>
          <h3 className="text-5xl md:text-7xl font-display font-bold text-coffee-800 tracking-tighter">
            The <span className="text-accent italic">Highlights</span>
          </h3>
        </div>
        <p className="text-coffee-500/80 max-w-sm text-lg leading-relaxed border-l-2 border-accent pl-6">
          Hand-picked favorites from our kitchens and roastery, specifically tailored for our Villagio guests.
        </p>
      </div>

      {/* Featured Sections */}
      <div className="space-y-32">
        
        {/* Coffee Section */}
        <section>
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-coffee-100 rounded-2xl flex items-center justify-center text-coffee-800">
              <Coffee size={24} />
            </div>
            <h4 className="text-3xl font-display font-bold text-coffee-950">The Morning Ritual</h4>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {getHighlights('Coffee', 3).map(item => (
              <div key={item.id} className="group cursor-pointer">
                <div className="aspect-[4/5] rounded-3xl overflow-hidden mb-6 relative">
                  <img src={item.image} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors" />
                </div>
                <h5 className="text-xl font-display font-bold text-coffee-950 mb-1">{item.name}</h5>
                <p className="text-coffee-500 text-sm mb-3">{item.description}</p>
                <p className="text-accent font-bold">{item.price}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Signature Food Section */}
        <section className="bg-coffee-950 -mx-4 px-4 py-24 rounded-[4rem] text-white">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-4 mb-10">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-accent">
                <Utensils size={24} />
              </div>
              <h4 className="text-3xl font-display font-bold">Signature Ghanaian Plates</h4>
            </div>
            <div className="grid lg:grid-cols-2 gap-12">
              {getHighlights('Food', 2).map(item => (
                <div key={item.id} className="flex flex-col sm:flex-row gap-8 items-center bg-white/5 p-8 rounded-[3rem] border border-white/10">
                  <div className="w-48 h-48 rounded-2xl overflow-hidden flex-shrink-0">
                    <img src={item.image} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h5 className="text-2xl font-display font-bold mb-2">{item.name}</h5>
                    <p className="text-white/60 text-sm mb-4 leading-relaxed">{item.description}</p>
                    <p className="text-accent text-xl font-bold">{item.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pastries Section */}
        <section>
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-coffee-100 rounded-2xl flex items-center justify-center text-coffee-800">
              <Cookie size={24} />
            </div>
            <h4 className="text-3xl font-display font-bold text-coffee-950">Sweet Treats</h4>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {getHighlights('Pastries', 4).map(item => (
              <div key={item.id} className="p-6 bg-white rounded-3xl border border-stone-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="aspect-square rounded-2xl overflow-hidden mb-4">
                  <img src={item.image} className="w-full h-full object-cover" />
                </div>
                <h5 className="font-display font-bold text-lg mb-1">{item.name}</h5>
                <p className="text-accent font-bold text-sm">{item.price}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
      
      <div className="mt-32 text-center">
        <div className="p-12 bg-accent/10 rounded-[3rem] border border-accent/20 max-w-3xl mx-auto">
          <h4 className="text-3xl font-display font-bold text-coffee-950 mb-4">Looking for something else?</h4>
          <p className="text-coffee-600 mb-8">Browse our entire range including seasonal specials and our full selection of teas and beverages.</p>
          <Link 
            to="/catalog"
            className="inline-block px-12 py-5 bg-coffee-800 text-white text-xs uppercase tracking-[0.3em] font-black rounded-full hover:bg-accent transition-all duration-500 shadow-xl"
          >
            Explore Full Catalog
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Menu;
