
import React from 'react';
import { MapPin, Phone, Share2, Bookmark, Navigation, ArrowRight, Clock } from 'lucide-react';
import { BUSINESS_HOURS } from '../constants';

const Contact: React.FC = () => {
  const handleCall = () => { window.location.href = 'tel:0540102889'; };
  const handleDirections = () => { window.open('https://maps.google.com/?q=JRCC+3Q6,Accra', '_blank'); };
  
  return (
    <div className="max-w-7xl mx-auto space-y-24 pb-20">
      <div className="grid lg:grid-cols-2 gap-8 items-stretch">
        <div className="bg-coffee-950 text-white p-10 md:p-16 rounded-[3rem] flex flex-col shadow-2xl">
          <h2 className="text-accent font-bold tracking-[0.3em] uppercase text-xs mb-8">Visit Us</h2>
          <h3 className="text-5xl md:text-6xl font-display font-bold mb-12 tracking-tighter">
            Villagio <span className="text-accent italic">Primavera</span>
          </h3>

          <div className="space-y-10 mb-16 flex-grow">
            <div className="flex items-start gap-6 group cursor-pointer" onClick={handleDirections}>
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                <MapPin size={24} />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Address</p>
                <p className="text-xl font-medium">JRCC+3Q6, Villagio, Accra</p>
                <p className="text-white/50 text-sm mt-1">Directly opposite Accra Mall entrance.</p>
              </div>
            </div>

            <div className="flex items-start gap-6 group cursor-pointer" onClick={handleCall}>
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                <Phone size={24} />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest font-bold text-white/40 mb-2">Direct Line</p>
                <p className="text-xl font-medium">054 010 2889</p>
                <p className="text-white/50 text-sm mt-1">Call for takeaways or reservations.</p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <button 
              onClick={handleDirections}
              className="flex-1 min-w-[200px] inline-flex items-center justify-center gap-3 px-8 py-5 bg-accent text-coffee-950 text-[10px] uppercase tracking-[0.2em] font-black rounded-2xl hover:bg-white transition-all"
            >
              Get Directions <ArrowRight size={14} />
            </button>
            <div className="flex gap-4">
              <button className="p-5 bg-white/5 rounded-2xl text-white hover:bg-white/10 transition-colors">
                <Share2 size={20} />
              </button>
              <button className="p-5 bg-white/5 rounded-2xl text-white hover:bg-white/10 transition-colors">
                <Bookmark size={20} />
              </button>
            </div>
          </div>
        </div>

        <div className="relative rounded-[3rem] overflow-hidden min-h-[500px] border border-coffee-100 shadow-xl">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.4727533604135!2d-0.15416668478441142!3d5.6327777959005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9b7f5730a083%3A0xc6e462c76a5b6d9e!2sVillagio%20Primavera!5e0!3m2!1sen!2sgh!4v1675432109876!5m2!1sen!2sgh" 
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: 'grayscale(1) invert(0.1) contrast(1.1)' }} 
            allowFullScreen 
            loading="lazy" 
          />
        </div>
      </div>

      {/* Opening Hours Section - Filling the page */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-[3rem] p-12 border border-stone-100 shadow-sm">
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-accent/10 rounded-2xl flex items-center justify-center text-accent">
              <Clock size={24} />
            </div>
            <h4 className="text-3xl font-display font-bold text-coffee-950">Daily Schedule</h4>
          </div>
          <div className="space-y-6">
            {BUSINESS_HOURS.map((slot, idx) => (
              <div key={idx} className="flex justify-between items-center pb-6 border-b border-stone-50 last:border-0">
                <span className="text-xl font-medium text-coffee-800">{slot.day}</span>
                <span className="text-2xl font-display font-bold text-accent">{slot.hours}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-coffee-50 rounded-[3rem] p-12 border border-coffee-100">
           <h4 className="text-2xl font-display font-bold text-coffee-950 mb-6">Accessibility</h4>
           <ul className="space-y-6 text-coffee-600">
             <li className="flex gap-4">
               <div className="w-6 h-6 rounded-full bg-accent/20 flex-shrink-0" />
               <p>Free underground parking for café guests (first 2 hours).</p>
             </li>
             <li className="flex gap-4">
               <div className="w-6 h-6 rounded-full bg-accent/20 flex-shrink-0" />
               <p>Full wheelchair access through the main tower lobby.</p>
             </li>
             <li className="flex gap-4">
               <div className="w-6 h-6 rounded-full bg-accent/20 flex-shrink-0" />
               <p>High-speed guest Wi-Fi available for work sessions.</p>
             </li>
           </ul>
        </div>
      </div>
    </div>
  );
};

export default Contact;
