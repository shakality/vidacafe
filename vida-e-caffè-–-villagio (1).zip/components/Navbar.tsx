
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Coffee } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Menu', path: '/menu' },
    { name: 'About', path: '/about' },
    { name: 'Reviews', path: '/reviews' },
    { name: 'Contact', path: '/contact' },
  ];

  const isHome = location.pathname === '/';

  return (
    <div className="fixed w-full z-50 flex justify-center pt-6 px-4 pointer-events-none">
      <nav 
        className={`pointer-events-auto transition-all duration-700 ease-in-out flex items-center justify-between max-w-5xl w-full px-6 py-4 rounded-full border border-white/10 ${
          scrolled || !isHome
          ? 'bg-coffee-950/90 backdrop-blur-xl shadow-[0_8px_32px_rgba(26,18,11,0.4)] border-white/20' 
          : 'bg-transparent border-transparent'
        }`}
      >
        <Link to="/" className="flex items-center gap-2 group outline-none">
          <div className={`p-2 rounded-full transition-colors ${scrolled || !isHome ? 'bg-accent' : 'bg-white/10'}`}>
            <Coffee className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-display font-bold text-white tracking-tight">
            Vida <span className="text-accent italic">e</span> Caffè
          </span>
        </Link>
        
        <div className="hidden md:flex items-center space-x-1">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`px-5 py-2 text-[11px] uppercase tracking-[0.2em] font-bold transition-all hover:bg-white/5 rounded-full ${
                location.pathname === link.path ? 'text-accent' : 'text-white/80 hover:text-white'
              }`}
            >
              {link.name}
            </Link>
          ))}
          <Link 
            to="/contact"
            className="ml-4 px-6 py-2.5 bg-white text-coffee-950 text-[10px] uppercase tracking-widest font-black rounded-full hover:bg-accent hover:text-white transition-all"
          >
            Find Us
          </Link>
        </div>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 text-white hover:bg-white/10 rounded-full transition-colors"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Sidebar */}
      <div className={`fixed inset-0 bg-coffee-950 z-[60] transition-transform duration-700 ease-in-out md:hidden pointer-events-auto ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full p-12">
          <div className="flex justify-between items-center mb-16">
            <span className="text-2xl font-display font-bold text-white">Vida e Caffè</span>
            <button onClick={() => setIsOpen(false)} className="p-3 text-white bg-white/5 rounded-full">
              <X size={32} />
            </button>
          </div>
          <div className="flex flex-col space-y-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`text-4xl font-display font-bold transition-colors ${
                  location.pathname === link.path ? 'text-accent' : 'text-white/50 hover:text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>
          <div className="mt-auto border-t border-white/10 pt-8">
            <p className="text-white/40 text-sm uppercase tracking-widest mb-4">Visit Us</p>
            <p className="text-white text-lg">Villagio, Accra</p>
            <p className="text-accent font-bold mt-2">054 010 2889</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
