
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowDownRight, MousePointer2 } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[100svh] w-full flex flex-col items-center justify-center overflow-hidden bg-coffee-950 pt-32 pb-20">
      <div 
        className="absolute inset-0 bg-cover bg-center z-0 opacity-40 animate-slow-zoom scale-110"
        style={{ backgroundImage: `url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&q=80&w=2000')` }}
      />
      
      {/* Dynamic Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-coffee-950/80 via-transparent to-coffee-950 z-10" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-transparent to-coffee-950/90 z-10" />

      {/* Floating Signature Badge */}
      <div className="absolute top-40 right-[10%] z-20 hidden xl:block animate-bounce [animation-duration:5s]">
        <div className="w-32 h-32 rounded-full border border-accent/30 backdrop-blur-md flex items-center justify-center text-center p-4 transform -rotate-12">
          <p className="text-[10px] uppercase tracking-widest text-accent font-black leading-tight">
            Certified <br/> 100% Arabica <br/> Signature Blend
          </p>
        </div>
      </div>

      <div className="relative z-20 container mx-auto px-6 text-center">
        <div className="inline-block px-4 py-1.5 rounded-full border border-accent/30 bg-accent/10 backdrop-blur-sm text-accent text-[10px] uppercase tracking-[0.3em] font-bold mb-8 animate-slide-up">
          EST. 2012 • ACCRA GHANA
        </div>
        
        <h1 className="text-[clamp(3rem,10vw,8rem)] font-display font-bold text-white leading-[0.85] tracking-tighter mb-10 animate-slide-up [animation-delay:100ms]">
          Refined Coffee.<br/>
          <span className="text-accent italic">Serene Vibe.</span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-2xl text-white/80 font-light leading-relaxed mb-16 animate-slide-up [animation-delay:200ms]">
          Experience the art of European café culture at Villagio towers. Where premium roasts meet Accra's most sophisticated sanctuary.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-8 animate-slide-up [animation-delay:400ms]">
          <Link 
            to="/catalog"
            className="group px-12 py-6 bg-accent text-coffee-950 text-xs uppercase tracking-[0.3em] font-black rounded-full hover:bg-white transition-all duration-700 shadow-[0_0_50px_rgba(197,160,89,0.3)]"
          >
            Explore Menu
          </Link>
          <Link 
            to="/about"
            className="flex items-center gap-4 text-white group"
          >
            <span className="text-xs font-bold uppercase tracking-widest border-b border-white/20 group-hover:border-accent transition-all pb-2">Discover Our Story</span>
            <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-white group-hover:text-coffee-950 transition-all">
              <ArrowDownRight size={20} />
            </div>
          </Link>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-4 animate-pulse">
        <div className="w-px h-16 bg-gradient-to-b from-transparent via-accent to-transparent" />
        <span className="text-[10px] uppercase tracking-[0.4em] text-accent font-bold">Scroll Down</span>
      </div>

      <div className="absolute bottom-12 left-10 right-10 z-20 hidden lg:flex justify-between items-end">
        <div className="flex gap-4 items-center">
          <div className="w-12 h-12 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center text-accent">
            <MousePointer2 size={20} />
          </div>
          <div>
            <p className="text-accent font-display italic text-2xl mb-0">Open daily</p>
            <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Until 8:00 PM</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-accent font-display italic text-2xl mb-0">Villagio Towers</p>
          <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold">Airport Residential, Accra</p>
        </div>
      </div>
    </section>
  );
};

export default Hero;
